# frc
FRC Robot code

Great Ukrainian team of young and ambitious students are developing this robot
You can support us at GoFundMe
https://www.gofundme.com/f/rv2wp2-help-cyberpunks-to-participate-in-the-competition?utm_source=customer&utm_medium=copy_link-tip&utm_campaign=p_cp+share-sheet

